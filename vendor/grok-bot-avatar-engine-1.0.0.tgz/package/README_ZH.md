<p align="center">
  <img src="assets/hero.png" alt="Grok Bot 头像：pebble、cloud、sparkle、flower、heart、star" width="1200">
</p>

<h1 align="center">grok-bot-avatar-engine</h1>

<p align="center">
  Grok Bot 的头像引擎：25 种形状、11 种颜色、12 种状态、agent id 推导、
  主 bot 星标、bot 条和 PNG 导出。
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/grok-bot-avatar-engine"><img alt="npm" src="https://img.shields.io/npm/v/grok-bot-avatar-engine?color=f59312"></a>
  <a href="LICENSE"><img alt="license" src="https://img.shields.io/badge/license-MIT-blue"></a>
  <img alt="module" src="https://img.shields.io/badge/module-ESM-f59312">
</p>

---

这个包直接包含 Grok Bot 0.70.2 网页客户端的头像运行时，外面只加了一层很小的、无依赖的 API。
形状、调色板、眼神、呼吸动画、主 bot 星标和缺口遮罩都不是重画的近似版本，而是线上实现本身。

- **随处可用的静态渲染**：在 Node 和浏览器里生成独立 SVG 字符串或 data URL。
- **浏览器内实时头像**：挂载到 shadow root，眼睛会跟随指针。
- **Agent 身份**：任意 agent id 都能稳定推导出形状和颜色，也可以单独覆盖。
- **Bot 条**：紧凑排列，支持单个 bot 控制、点头/回应动作和 PNG 导出。
- **一次 import**：单个 ESM 包，React 已打包在内，没有 peer 依赖。

> 非官方项目，与 xAI 无隶属或背书关系。来源与授权请读 [NOTICE](NOTICE)。

## 安装

```sh
npm install grok-bot-avatar-engine
```

静态渲染需要 Node 18+。实时头像需要支持 shadow DOM 的浏览器；`capture()` 和
`renderAvatarPng()` 还需要 canvas。

## 快速开始

### 静态 SVG

```js
import { renderAvatarSvg, renderAvatarDataUrl } from 'grok-bot-avatar-engine';

// 形状和颜色由 agent id 推导。
const svg = renderAvatarSvg({ agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201', size: 128 });

// 指定外观并固定主题。
const dark = renderAvatarSvg({ shape: 'cloud', color: 'blue', theme: 'dark', size: 96 });

// 可直接放进 <img src>。
const src = renderAvatarDataUrl({ shape: 'heart', color: 'magenta', size: 64 });
```

默认 `theme: 'auto'` 时，SVG 内部会带 `prefers-color-scheme` 规则，调色板颜色会自行适配，
即使放在 `<img>` 里也生效。

### 实时头像

```js
import { createAvatar } from 'grok-bot-avatar-engine';

const avatar = createAvatar(document.querySelector('#bot'), {
  agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201',
  state: 'working',
  main: true,          // 星标 + 轮廓缺口
  size: 160,
  theme: 'auto',
});

avatar.setState('happy');
avatar.setShape('cloud');
avatar.setColor('violet');

const png = await avatar.capture(512); // data:image/png;...
avatar.destroy();
```

目标元素需要有尺寸：传 `size`，或用 CSS 设定。其余 DOM 都在 shadow root 内，页面样式不会渗入。

### Bot 条

```js
import { createStrip } from 'grok-bot-avatar-engine';

const strip = createStrip(document.querySelector('#team'), {
  mark: 44,
  bots: [
    { id: 'main', agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201', main: true },
    { id: 'ops', shape: 'hex', color: 'green', state: 'working' },
    { id: 'design', agentId: 'b6f0623e-8d7b-4c73-9c9e-52f6a7f1c001' },
  ],
});

strip.nodNeighbors();        // 相邻两个 bot 对视点头
strip.acknowledge('ops');    // 单个 bot 眨眼并低头
await strip.capture('main'); // 导出单个格子的 PNG
strip.destroy();
```

### 身份推导

```js
import { resolveAvatar } from 'grok-bot-avatar-engine';

resolveAvatar('33cf1aae-3a51-452d-b761-34a6ccb62201');
// {
//   agentId: '33cf1aae-...',
//   shape: 'sparkle',
//   color: 'brown',
//   hash: 2400509875,
//   sources: { shape: 'id-default', color: 'id-default' }
// }
```

哈希是对 id 的 UTF-16 码元做 FNV-1a。形状从 13 种默认形状里取，颜色从 10 种默认颜色里取
（`black` 不会被自动分配）。传入 `shape`/`color`（或 `avatarShape`/`avatarColor`）可单独覆盖。

## API

### 渲染入口

| 导出 | 环境 | 返回 |
| --- | --- | --- |
| `renderAvatarSvg(options)` | 任意 | SVG 字符串 |
| `renderAvatarDataUrl(options)` | 任意 | `data:image/svg+xml,...` |
| `renderAvatarPng(options)` | 浏览器 | `Promise<string>` PNG data URL |
| `createAvatar(target, options)` | 浏览器 | `AvatarHandle` |
| `createStrip(target, options)` | 浏览器 | `StripHandle` |

`renderAvatar*` 参数：`agentId`、`shape`、`color`、`avatarShape`、`avatarColor`、`size`
（默认 128）、`ink`（覆盖填充色）、`theme`（`'auto' | 'light' | 'dark'`）、`id`、`fill`
（填充比例，`(0, 1]`）。

### `createAvatar` 参数

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `agentId` | `string` | — | 未显式指定时用于推导形状/颜色 |
| `shape` | `AvatarShape` | 推导 | 25 种形状之一 |
| `color` | `string` | 推导 | 调色板名称或任意 CSS 颜色 |
| `state` | `AvatarState` | `'idle'` | 见下方状态列表 |
| `seed` | `string \| number` | id/形状 | 动画种子 |
| `id` | `string` | — | 写入 SVG `id` |
| `main` | `boolean` | `false` | 星标 + 轮廓缺口 |
| `follow` | `boolean` | `true` | 眼睛跟随指针 |
| `visible` | `boolean` | `true` | `false` 时冻结画面 |
| `reducedMotion` | `boolean` | `false` | 静态姿势 |
| `theme` | `'auto' \| 'light' \| 'dark'` | `'auto'` | 调色板名称的解析方式 |
| `size` | `number` | — | 设置宿主宽高（px） |
| `className` | `string` | — | 加到宿主上 |
| `style` | `Partial<CSSStyleDeclaration>` | — | 应用到宿主 |

实例方法：`update(patch)`、`setState`、`setShape`、`setColor`、`setMain`、`setVisible`、
`setReducedMotion`、`blink`、`look(direction)`、`gaze([x, y] | null)`、`setExpression`、
`restart`、`poke(x, y)`、`capture(size)`、`destroy`，以及 `element`。

### `createStrip` 参数

`bots`（元素为 `{ id, agentId, shape, color, state, seed, main }`）、`mark`（格子边长，默认 40）、
`theme`、`reducedMotion`、`className`。

实例方法：`get(id)`、`update({ bots, mark, theme, reducedMotion })`、`nodNeighbors()`、
`acknowledge(id)`、`capture(id, size)`、`destroy`，以及 `element`。

### 常量与工具

- `STATES`、`STATE_ALIASES`（`wide → listening`，`comet → streaming`）、`mapState(state)`
- `SHAPES`（25）、`DEFAULT_SHAPES`（13）、`isShape(value)`
- `COLORS`（11）、`DEFAULT_COLORS`（10）、`PALETTE`（label + base/light/dark）、`isColor(value)`
- `resolveAvatar(input)`、`hashAgentId(id)`、`colorHex(name, theme?)`、`colorCss(name)`
- `FALLBACK_INK`、`FALLBACK_SHAPE`、`AVATAR_SIZE_DEFAULT`、`AVATAR_CSS`

```text
状态   idle listening thinking streaming searching working
       waiting blocked finished failed sleeping happy

形状   blob pebble bean egg squircle tablet capsule cylinder hex gem crystal
       wedge shield dome arch cloud teardrop leaf square sparkle clover flower
       heart house star

颜色   black brown red orange yellow green cyan blue violet magenta gray
```

`AVATAR_CSS` 是 shadow root 内使用的样式表；只有你自己渲染内部结构时才需要它。

## 说明

- **包体积**约 797 KiB（压缩后），因为包含完整运行时和 React 19。内部基本没有可 tree-shake 的空间。
- **主题**：调色板名称按主题解析。静态 SVG 在 `theme: 'auto'` 时通过 SVG 内部的
  `prefers-color-scheme` 生效；实时头像在宿主上解析，并随系统主题变化更新。CSS 颜色按原样使用。
- **CSP**：实时头像会向 shadow root 注入 `<style>`，`capture()` 会把 `blob:` 图片画进 canvas。
  如果启用了内容安全策略，需要允许内联样式和 `img-src blob:`。
- **截图**按指定尺寸栅格化 SVG，背景透明。

## 开发

```sh
npm install
npm run build       # 把 src/ 与 runtime/ 打包进 dist/
npm test            # 针对构建产物跑 Node 测试
npm run typecheck   # 校验 types/index.d.ts 及示例用法
npm run test:browser # Playwright DOM/截图测试（找不到 Chromium 时自动跳过）
npm run demo        # 在 http://127.0.0.1:4173/ 提供 demo/
```

浏览器测试找不到 Chromium 时，可设置 `PLAYWRIGHT_CHROMIUM_EXECUTABLE` 或 `CHROME_PATH`；
`AVATAR_TEST_SHOT=/path.png` 会保存测试页截图。

目录结构：`runtime/` 是内置的 Grok Bot 运行时，`src/` 是包装层与公开 API，`types/` 是手写类型，
`dist/` 是发布产物。

## 来源与授权

包装层、类型、构建脚本、demo 和测试使用 MIT 协议。`runtime/` 下的头像运行时提取自
Grok Bot 0.70.2 客户端，权利归各自所有者，MIT 协议不覆盖这部分。二次分发或商业使用前请阅读
[NOTICE](NOTICE)。如果需要彻底干净的实现，可以替换 `runtime/`，同时保持导出名不变。
